const settings = {
    API_DOMAIN: "http://127.0.0.1:8000",
    CHAT_DOMAIN: "http://127.0.0.1:4000"
};

export default settings;